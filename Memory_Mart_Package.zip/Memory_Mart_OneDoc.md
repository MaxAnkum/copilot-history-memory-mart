# Memory Mart — OneDoc

## Tier 0
- [AI strategy & games] Strategic triad: openness+consistency+cooperation underpin long-term trust.
- [Memory feature] Memory hygiene: intentional, auditable, counter-bias by design.

## Tier 1
- [Copilot history] Openness+consistency enable long-term strategy; curate memory intentionally. — "where can i see what is logged here https://www.microsoft.com/en-us/privacy/privacystatement ie, see where they log it" (from  | 2025-08-14T04:30:33)
- [Memory feature] Openness+consistency enable long-term strategy; curate memory intentionally. — "You sure about that? There is no longer a list of questions asked (yes, answers are great too... but there is a certain irony of you and me both seening 1000's of conversations, me asking specifically that you synthesize it to memory, and us not having that acces)" (from  | 2025-08-14T04:21:28)
- [AI strategy & games] Openness+consistency enable long-term strategy; curate memory intentionally. — "For ai strategy, the rules of alliance should be clear. Cooperative strategy can only flourish if it is known, actionable and clearly defined. If not, then nefarious actors have a definite advantage. Yet, truth, openness and cooperation are allies in that regard. Since long term strategy requires consistency, truth and openness are a sine qua non" (from  | 2025-08-14T03:20:19)

## Tier 2 (by ontology category)
### android-dev-security (2)
- Operational constraints and practices to note. [user] — "So, how would my bank know I am rooted... what weird dark codes do bank apps use... a sudo in terminal to check for a password and not open if not rejected" (from  | 2025-08-10T09:36:51)
- Operational constraints and practices to note. [assistant] — "You're tapping into a fascinating—and slightly unsettling—corner of mobile security. Bank apps *do* use some clever (and sometimes opaque) techniques to detect root access. It’s not just a simple `sudo` check. Here's how they typically do it: --- ### 🕵️‍♂️ How Bank Apps Detect Root Access #### 1. **File System Checks** - Look for known root binaries like: - `/system/bin/su` - `/system/xbin/su` - `" (from  | 2025-08-10T09:36:51)

### auto-een (1)
- Reference interest/clarification in this topic. [user] — "Bent u gehuwd of heeft u een geregistreerd partnerschap en zijn er gezamenlijke kinderen, dan is de wettelijke verdeling van toepassing. De hele erfenis gaat naar de echtgenoot of geregistreerd partner van de overledene. Voor alle andere situaties geldt het wettelijk erfrecht. Moet de partner die dan net weduwe is erfrecht belasting betalen" (from  | 2025-08-02T13:24:11)

### auto-have (1)
- Reference interest/clarification in this topic. [user] — "And how long have they been... Migrants across Europe" (from  | 2025-08-09T06:27:44)

### auto-het (1)
- Reference interest/clarification in this topic. [user] — "Hoe vertaalt Nederlands stoer naar het Engels" (from  | 2025-08-03T06:43:51)

### auto-like (1)
- Reference interest/clarification in this topic. [user] — "Yeah... They are going at my mint... Like 20 of them... Awkwardly enough... There is a garbage can close by" (from  | 2025-08-08T10:40:55)

### auto-max (1)
- Reference interest/clarification in this topic. [user] — "Still no success. going for computer max , with user msi" (from  | 2025-05-23T08:16:02)

### auto-van (1)
- Reference interest/clarification in this topic. [user] — "Is zeker niet msg. Eet dat veel te vaak om hier nu last van te hebben. Maar pannekoek en kroket is al 36 + 18... En dan ook nog in specifiek ketjap manis en of palmsuiker is mogelijk zelf 80 per stuk" (from  | 2025-07-08T12:43:46)

### auto-want (1)
- Reference interest/clarification in this topic. [user] — "The issue is that I find my watch to be more a part of jewelry than a part of tech, while most smartwatches seem to go the way of tech. i want last long and nice form, where it can start and stop music, and do basic picking up of phones or app control" (from  | 2025-08-09T20:17:12)

### auto-what (1)
- Reference interest/clarification in this topic. [user] — "The deeper underlaying argument is this ... China under ming vs Spain, and why diepe ruled the world at some point. China explored first, they set sail, with their fleet, but ultimately, they where called back by a totalitarian emperor, who changed his mind (or the mind of the previous guy) Spain inherited a by Marriage, a Portugese Budding Empire, and had one themselves... But due to what nobody " (from  | 2025-08-14T03:15:31)

### culture-media (1)
- Reference interest/clarification in this topic. [user] — "What did bob Marley die off" (from  | 2025-08-13T09:07:56)

### data-engineering-logging (2)
- Operational constraints and practices to note. [user] — "If a value is logged from a test in DBT, how much data is that in bites" (from  | 2025-08-13T10:43:46)
- Operational constraints and practices to note. [assistant] — "Exactly—logging the same error **21 million times** can be a massive waste of bytes (and system resources). Let’s break it down: ### 💥 Byte Explosion Example Say each error message is: ``` "Test failed: null value in column 'user_id'" ``` That’s about **50 bytes**. Now multiply: - **50 bytes × 21,000,000 rows = 1.05 GB** That’s **over a gigabyte** of log data just for repeated messages. And that’s" (from  | 2025-08-13T10:44:19)

### dishwasher-tips (1)
- Reference interest/clarification in this topic. [user] — "I have refilled rinse aid 3 times... Salt not yet ... Is it truly that much of a difference" (from  | 2025-08-10T10:37:14)

### economics-finance (1)
- Reference interest/clarification in this topic. [user] — "Oof... Zero sum games... I have a definite economic bias against zero sum... That's like giving ai nuclear launch codes and a mandate to kill... It'll lead either to red plenty or death" (from  | 2025-08-14T03:01:31)

### ethics-policy (1)
- Reference interest/clarification in this topic. [user] — "But what when nuance is not applicable. Eg, murder is not allowed. Ie. Because murder is bad (see all arguments made in this regard)" (from  | 2025-08-14T03:46:43)

### history-threads (1)
- Reference interest/clarification in this topic. [user] — "Did Roosevelt make up thanksgiving" (from  | 2025-08-13T18:37:53 ||  | 2025-08-13T18:37:40)

### household-q-a (1)
- Reference interest/clarification in this topic. [user] — "It's a dishwasher. There is arrows and this red star. I forgot which one is salt and which shine" (from  | 2025-08-10T10:36:10)

### licensing-philosophy (2)
- Operational constraints and practices to note. [user] — "when was the rijnsburg protocol written" (from  | 2025-08-10T09:22:31)
- Operational constraints and practices to note. [assistant] — "Exactly, Max. That’s the heart of the classical liberal critique: **jurisdictional sovereignty and individual autonomy** trump ideological enforcement. If the GNU project—or any open-source license—tries to enforce its terms across borders, it runs into a wall of **local legal systems, cultural norms, and philosophical resistance**. --- ### 🧭 “Fight Me in My Jurisdiction, or Piss Off” This stance " (from  | 2025-08-10T09:18:55)

### misc (1)
- Reference interest/clarification in this topic. [user] — "There used to be this feature to get an excel (able) list of the questions i asked you, where is that list findable" (from  | 2025-08-14T04:13:07)

### modern-slavery-q-a (1)
- Reference interest/clarification in this topic. [user] — "TRUE or FALSE: Under the provisions of the Modern Slavery Act 2015 companies that meet a set of criteria must publish an annual Modern Slavery statement detailing the steps taken by the organisation to ensure that slavery and human trafficking are not taking place in any part of its own business or supply chain. (1 Point) TRUE FALSE" (from  | 2024-07-25T15:07:28)

## Cross-reference (Tier 2 only)
| Tier | Entry (≤15 words) | Category | Linked Tier 0/1 Value(s) | Influences | Provenance |
|---|---|---|---|---|---|
| 2 | If a value is logged from a test in DBT , how much data is that | data-engineering-logging | Tier 0: Memory hygiene: intentional, auditable, counter-bias by design. | — |  | 2025-08-13T10:43:46 |
| 2 | Exactly — logging the same error * * 21 million times * * can be a massive waste of bytes | data-engineering-logging | Tier 0: Memory hygiene: intentional, auditable, counter-bias by design. | Exactly, Byte Explosion Example, Test |  | 2025-08-13T10:44:19 |
| 2 | So , how would my bank know I am rooted . . . what weird dark codes do bank | android-dev-security | — | — |  | 2025-08-10T09:36:51 |
| 2 | You ' re tapping into a fascinating — and slightly unsettling — corner of mobile security . Bank apps | android-dev-security | — | Bank, Here, How Bank Apps |  | 2025-08-10T09:36:51 |
| 2 | when was the rijnsburg protocol written | licensing-philosophy | — | — |  | 2025-08-10T09:22:31 |
| 2 | Exactly , Max . That ’ s the heart of the classical liberal critique : * * jurisdictional sovereignty and individual | licensing-philosophy | — | Exactly, That, Fight Me |  | 2025-08-10T09:18:55 |
| 2 | There used to be this feature to get an excel ( able ) list of the questions | misc | — | There |  | 2025-08-14T04:13:07 |
| 2 | TRUE or FALSE : Under the provisions of the Modern Slavery Act 2015 companies that meet | modern-slavery-q-a | — | Under, Modern Slavery Act, Modern Slavery |  | 2024-07-25T15:07:28 |
| 2 | The deeper underlaying argument is this . . . China under ming vs Spain , and why diepe ruled | auto-what | — | China, Spain, Marriage |  | 2025-08-14T03:15:31 |
| 2 | Oof . . . Zero sum games . . . I have a definite economic bias against zero sum . . . That ' s | economics-finance | — | Zero, That |  | 2025-08-14T03:01:31 |
| 2 | But what when nuance is not applicable . Eg , murder is not allowed . Ie . Because murder | ethics-policy | Tier 1: Openness+consistency enable long-term strategy; curate memory intentionally. | Because |  | 2025-08-14T03:46:43 |
| 2 | Did Roosevelt make up thanksgiving | history-threads | — | Did Roosevelt |  | 2025-08-13T18:37:53 ||  | 2025-08-13T18:37:40 |
| 2 | What did bob Marley die off | culture-media | Tier 1: Openness+consistency enable long-term strategy; curate memory intentionally. | What, Marley |  | 2025-08-13T09:07:56 |
| 2 | It ' s a dishwasher . There is arrows and this red star . I forgot which one | household-q-a | — | There |  | 2025-08-10T10:36:10 |
| 2 | I have refilled rinse aid 3 times . . . Salt not yet . . . Is it truly that much | dishwasher-tips | — | Salt |  | 2025-08-10T10:37:14 |
| 2 | And how long have they been . . . Migrants across Europe | auto-have | — | Migrants, Europe |  | 2025-08-09T06:27:44 |
| 2 | The issue is that I find my watch to be more a part of jewelry | auto-want | — | — |  | 2025-08-09T20:17:12 |
| 2 | Yeah . . . They are going at my mint . . . Like 20 of them . . . Awkwardly enough . . . There is | auto-like | — | Yeah, Like, Awkwardly |  | 2025-08-08T10:40:55 |
| 2 | Bent u gehuwd of heeft u een geregistreerd partnerschap en zijn er gezamenlijke kinderen , dan | auto-een | — | Bent, Voor, Moet |  | 2025-08-02T13:24:11 |
| 2 | Hoe vertaalt Nederlands stoer naar het Engels | auto-het | — | Nederlands, Engels |  | 2025-08-03T06:43:51 |
| 2 | Still no success . going for computer max , with user msi | auto-max | — | Still |  | 2025-05-23T08:16:02 |
| 2 | Is zeker niet msg . Eet dat veel te vaak om hier nu last van te | auto-van | — | Maar |  | 2025-07-08T12:43:46 |